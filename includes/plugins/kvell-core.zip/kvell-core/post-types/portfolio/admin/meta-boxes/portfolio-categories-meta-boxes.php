<?php

if ( ! function_exists( 'kvell_edge_portfolio_category_additional_fields' ) ) {
	function kvell_edge_portfolio_category_additional_fields() {
		
		$fields = kvell_edge_add_taxonomy_fields(
			array(
				'scope' => 'portfolio-category',
				'name'  => 'portfolio_category_options'
			)
		);
		
		kvell_edge_add_taxonomy_field(
			array(
				'name'   => 'edgtf_portfolio_category_image_meta',
				'type'   => 'image',
				'label'  => esc_html__( 'Category Image', 'kvell-core' ),
				'parent' => $fields
			)
		);
	}
	
	add_action( 'kvell_edge_custom_taxonomy_fields', 'kvell_edge_portfolio_category_additional_fields' );
}