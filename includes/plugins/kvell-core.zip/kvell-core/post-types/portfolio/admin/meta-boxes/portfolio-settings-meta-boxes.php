<?php

if (!function_exists('kvell_core_map_portfolio_settings_meta')) {
    function kvell_core_map_portfolio_settings_meta() {
        $meta_box = kvell_edge_add_meta_box(array(
            'scope' => 'portfolio-item',
            'title' => esc_html__('Portfolio Settings', 'kvell-core'),
            'name'  => 'portfolio_settings_meta_box'
        ));

        kvell_edge_add_meta_box_field(array(
            'name'        => 'edgtf_portfolio_single_template_meta',
            'type'        => 'select',
            'label'       => esc_html__('Portfolio Type', 'kvell-core'),
            'description' => esc_html__('Choose a default type for Single Project pages', 'kvell-core'),
            'parent'      => $meta_box,
            'options'     => array(
                ''                  => esc_html__('Default', 'kvell-core'),
                'huge-images'       => esc_html__('Portfolio Full Width Images', 'kvell-core'),
                'images'            => esc_html__('Portfolio Images', 'kvell-core'),
                'small-images'      => esc_html__('Portfolio Small Images', 'kvell-core'),
                'slider'            => esc_html__('Portfolio Slider', 'kvell-core'),
                'small-slider'      => esc_html__('Portfolio Small Slider', 'kvell-core'),
                'gallery'           => esc_html__('Portfolio Gallery', 'kvell-core'),
                'small-gallery'     => esc_html__('Portfolio Small Gallery', 'kvell-core'),
                'masonry'           => esc_html__('Portfolio Masonry', 'kvell-core'),
                'small-masonry'     => esc_html__('Portfolio Small Masonry', 'kvell-core'),
                'custom'            => esc_html__('Portfolio Custom', 'kvell-core'),
                'full-width-custom' => esc_html__('Portfolio Full Width Custom', 'kvell-core')
            )
        ));

        /***************** Gallery Layout *****************/

        $gallery_type_meta_container = kvell_edge_add_admin_container(
            array(
                'parent'     => $meta_box,
                'name'       => 'edgtf_gallery_type_meta_container',
                'dependency' => array(
                    'show' => array(
                        'edgtf_portfolio_single_template_meta' => array(
                            'gallery',
                            'small-gallery'
                        )
                    )
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_portfolio_single_gallery_columns_number_meta',
                'type'          => 'select',
                'label'         => esc_html__('Number of Columns', 'kvell-core'),
                'default_value' => '',
                'description'   => esc_html__('Set number of columns for portfolio gallery type', 'kvell-core'),
                'parent'        => $gallery_type_meta_container,
                'options'       => array(
                    ''      => esc_html__('Default', 'kvell-core'),
                    'two'   => esc_html__('2 Columns', 'kvell-core'),
                    'three' => esc_html__('3 Columns', 'kvell-core'),
                    'four'  => esc_html__('4 Columns', 'kvell-core')
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_portfolio_single_gallery_space_between_items_meta',
                'type'          => 'select',
                'label'         => esc_html__('Space Between Items', 'kvell-core'),
                'description'   => esc_html__('Set space size between columns for portfolio gallery type', 'kvell-core'),
                'default_value' => '',
                'options'       => kvell_edge_get_space_between_items_array(true),
                'parent'        => $gallery_type_meta_container
            )
        );

        /***************** Gallery Layout *****************/

        /***************** Masonry Layout *****************/

        $masonry_type_meta_container = kvell_edge_add_admin_container(
            array(
                'parent'     => $meta_box,
                'name'       => 'edgtf_masonry_type_meta_container',
                'dependency' => array(
                    'show' => array(
                        'edgtf_portfolio_single_template_meta' => array(
                            'masonry',
                            'small-masonry'
                        )
                    )
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_portfolio_single_masonry_columns_number_meta',
                'type'          => 'select',
                'label'         => esc_html__('Number of Columns', 'kvell-core'),
                'default_value' => '',
                'description'   => esc_html__('Set number of columns for portfolio masonry type', 'kvell-core'),
                'parent'        => $masonry_type_meta_container,
                'options'       => array(
                    ''      => esc_html__('Default', 'kvell-core'),
                    'two'   => esc_html__('2 Columns', 'kvell-core'),
                    'three' => esc_html__('3 Columns', 'kvell-core'),
                    'four'  => esc_html__('4 Columns', 'kvell-core')
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_portfolio_single_masonry_space_between_items_meta',
                'type'          => 'select',
                'label'         => esc_html__('Space Between Items', 'kvell-core'),
                'description'   => esc_html__('Set space size between columns for portfolio masonry type', 'kvell-core'),
                'default_value' => '',
                'options'       => kvell_edge_get_space_between_items_array(true),
                'parent'        => $masonry_type_meta_container
            )
        );

        /***************** Masonry Layout *****************/

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_show_title_area_portfolio_single_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__('Show Title Area', 'kvell-core'),
                'description'   => esc_html__('Enabling this option will show title area on your single portfolio page', 'kvell-core'),
                'parent'        => $meta_box,
                'options'       => kvell_edge_get_yes_no_select_array()
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'        => 'portfolio_info_top_padding',
                'type'        => 'text',
                'label'       => esc_html__('Portfolio Info Top Padding', 'kvell-core'),
                'description' => esc_html__('Set top padding for portfolio info elements holder. This option works only for Portfolio Images, Slider, Gallery and Masonry portfolio types', 'kvell-core'),
                'parent'      => $meta_box,
                'args'        => array(
                    'col_width' => 3,
                    'suffix'    => 'px'
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'        => 'portfolio_external_link',
                'type'        => 'text',
                'label'       => esc_html__('Portfolio External Link', 'kvell-core'),
                'description' => esc_html__('Enter URL to link from Portfolio List page', 'kvell-core'),
                'parent'      => $meta_box,
                'args'        => array(
                    'col_width' => 3
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'        => 'edgtf_portfolio_featured_image_meta',
                'type'        => 'image',
                'label'       => esc_html__('Featured Image', 'kvell-core'),
                'description' => esc_html__('Choose an image for Portfolio Lists shortcode where Hover Type option is Switch Featured Images', 'kvell-core'),
                'parent'      => $meta_box
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_portfolio_overlay_predefined_color_meta',
                'type'          => 'select',
                'label'         => esc_html__('Gallery Overlay Predefined Colors', 'kvell-core'),
                'description'   => esc_html__('Choose predefined overlay colors for single portfolio items when they appear in portfolio lists with gallery overlay hover type enabled.', 'kvell-core'),
                'default_value' => '',
                'parent'        => $meta_box,
                'options'       => array(
                    ''             => esc_html__('Default', 'kvell-core'),
                    'first-color'  => esc_html__('First Predefined Color', 'kvell-core'),
                    'second-color' => esc_html__('Second Predefined Color', 'kvell-core'),
                    'third-color'  => esc_html__('Third Predefined Color', 'kvell-core'),
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_portfolio_masonry_fixed_dimensions_meta',
                'type'          => 'select',
                'label'         => esc_html__('Dimensions for Masonry - Image Fixed Proportion', 'kvell-core'),
                'description'   => esc_html__('Choose image layout when it appears in Masonry type portfolio lists where image proportion is fixed', 'kvell-core'),
                'default_value' => '',
                'parent'        => $meta_box,
                'options'       => array(
                    ''                   => esc_html__('Default', 'kvell-core'),
                    'small'              => esc_html__('Small', 'kvell-core'),
                    'large-width'        => esc_html__('Large Width', 'kvell-core'),
                    'large-height'       => esc_html__('Large Height', 'kvell-core'),
                    'large-width-height' => esc_html__('Large Width/Height', 'kvell-core')
                )
            )
        );

        kvell_edge_add_meta_box_field(
            array(
                'name'          => 'edgtf_portfolio_masonry_original_dimensions_meta',
                'type'          => 'select',
                'label'         => esc_html__('Dimensions for Masonry - Image Original Proportion', 'kvell-core'),
                'description'   => esc_html__('Choose image layout when it appears in Masonry type portfolio lists where image proportion is original', 'kvell-core'),
                'default_value' => 'default',
                'parent'        => $meta_box,
                'options'       => array(
                    'default'     => esc_html__('Default', 'kvell-core'),
                    'large-width' => esc_html__('Large Width', 'kvell-core')
                )
            )
        );

        $all_pages = array();
        $pages = get_pages();
        foreach ($pages as $page) {
            $all_pages[$page->ID] = $page->post_title;
        }

        kvell_edge_add_meta_box_field(
            array(
                'name'        => 'portfolio_single_back_to_link',
                'type'        => 'select',
                'label'       => esc_html__('"Back To" Link', 'kvell-core'),
                'description' => esc_html__('Choose "Back To" page to link from portfolio Single Project page', 'kvell-core'),
                'parent'      => $meta_box,
                'options'     => $all_pages,
                'args'        => array(
                    'select2' => true
                )
            )
        );
    }

    add_action('kvell_edge_meta_boxes_map', 'kvell_core_map_portfolio_settings_meta', 41);
}