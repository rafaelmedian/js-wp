<?php

$text_classes[] = 'edgtf-pli-text-holder';
$overlay_predefined_color = get_post_meta( get_the_ID(), 'edgtf_portfolio_overlay_predefined_color_meta', true);
$text_classes[] = !empty( $overlay_predefined_color ) ? 'edgtf-overlay-' . $overlay_predefined_color : '';

?>

<?php echo kvell_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/image', $item_style, $params); ?>

<div <?php kvell_edge_class_attribute($text_classes); ?>>
	<div class="edgtf-pli-text-wrapper">
		<div class="edgtf-pli-text">
			<?php echo kvell_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/title', $item_style, $params); ?>

			<?php echo kvell_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/category', $item_style, $params); ?>

			<?php echo kvell_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/images-count', $item_style, $params); ?>
			
			<?php echo kvell_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/excerpt', $item_style, $params); ?>
		</div>
	</div>
</div>