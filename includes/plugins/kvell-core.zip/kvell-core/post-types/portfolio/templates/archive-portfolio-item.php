<?php
get_header();
kvell_edge_get_title();
do_action( 'kvell_edge_before_main_content' ); ?>
<div class="edgtf-container edgtf-default-page-template">
	<?php do_action( 'kvell_edge_after_container_open' ); ?>
	<div class="edgtf-container-inner clearfix">
		<?php
			$kvell_taxonomy_id   = get_queried_object_id();
			$kvell_taxonomy_type = is_tax( 'portfolio-tag' ) ? 'portfolio-tag' : 'portfolio-category';
			$kvell_taxonomy      = ! empty( $kvell_taxonomy_id ) ? get_term_by( 'id', $kvell_taxonomy_id, $kvell_taxonomy_type ) : '';
			$kvell_taxonomy_slug = ! empty( $kvell_taxonomy ) ? $kvell_taxonomy->slug : '';
			$kvell_taxonomy_name = ! empty( $kvell_taxonomy ) ? $kvell_taxonomy->taxonomy : '';
			
			kvell_core_get_archive_portfolio_list( $kvell_taxonomy_slug, $kvell_taxonomy_name );
		?>
	</div>
	<?php do_action( 'kvell_edge_before_container_close' ); ?>
</div>
<?php get_footer(); ?>
