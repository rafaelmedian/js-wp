<?php

get_header();

kvell_edge_get_title();

do_action('kvell_edge_before_main_content');

kvell_core_get_single_portfolio();

get_footer();