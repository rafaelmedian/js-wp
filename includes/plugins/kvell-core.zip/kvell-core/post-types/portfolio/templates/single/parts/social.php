<?php if(kvell_edge_options()->getOptionValue('enable_social_share') == 'yes' && kvell_edge_options()->getOptionValue('enable_social_share_on_portfolio-item') == 'yes') : ?>
    <h4 class="edgtf-ps-share-label"><?php esc_html_e( 'Share', 'kvell-core' ); ?></h4>
    <div class="edgtf-ps-info-item edgtf-ps-social-share">
        <?php echo kvell_edge_get_social_share_html() ?>
    </div>
<?php endif; ?>