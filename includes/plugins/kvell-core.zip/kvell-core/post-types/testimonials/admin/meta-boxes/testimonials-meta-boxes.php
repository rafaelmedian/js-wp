<?php

if ( ! function_exists( 'kvell_core_map_testimonials_meta' ) ) {
	function kvell_core_map_testimonials_meta() {
		$testimonial_meta_box = kvell_edge_add_meta_box(
			array(
				'scope' => array( 'testimonials' ),
				'title' => esc_html__( 'Testimonial', 'kvell-core' ),
				'name'  => 'testimonial_meta'
			)
		);
		
		kvell_edge_add_meta_box_field(
			array(
				'name'        => 'edgtf_testimonial_title',
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'kvell-core' ),
				'description' => esc_html__( 'Enter testimonial title', 'kvell-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		kvell_edge_add_meta_box_field(
			array(
				'name'        => 'edgtf_testimonial_text',
				'type'        => 'text',
				'label'       => esc_html__( 'Text', 'kvell-core' ),
				'description' => esc_html__( 'Enter testimonial text', 'kvell-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		kvell_edge_add_meta_box_field(
			array(
				'name'        => 'edgtf_testimonial_author',
				'type'        => 'text',
				'label'       => esc_html__( 'Author', 'kvell-core' ),
				'description' => esc_html__( 'Enter author name', 'kvell-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		kvell_edge_add_meta_box_field(
			array(
				'name'        => 'edgtf_testimonial_author_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Author Position', 'kvell-core' ),
				'description' => esc_html__( 'Enter author job position', 'kvell-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
	}
	
	add_action( 'kvell_edge_meta_boxes_map', 'kvell_core_map_testimonials_meta', 95 );
}