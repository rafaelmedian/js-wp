<button type="submit" <?php kvell_edge_inline_style($button_styles); ?> <?php kvell_edge_class_attribute($button_classes); ?> <?php echo kvell_edge_get_inline_attrs($button_data); ?> <?php echo kvell_edge_get_inline_attrs($button_custom_attrs); ?>>
    <span class="edgtf-btn-text"><?php echo esc_html($text); ?></span>
    <?php echo kvell_edge_icon_collections()->renderIcon($icon, $icon_pack); ?>
    <?php if ($button_direction_aware_hover === 'yes'){ ?>
	    <span class="edgtf-button-overlay-holder">
	    	<span class="edgtf-button-overlay"></span>
	    </span>
    <?php } ?>
</button>