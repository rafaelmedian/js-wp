<?php

if ( ! function_exists( 'kvell_core_add_highlight_shortcodes' ) ) {
	function kvell_core_add_highlight_shortcodes( $shortcodes_class_name ) {
		$shortcodes = array(
			'KvellCore\CPT\Shortcodes\Highlight\Highlight'
		);
		
		$shortcodes_class_name = array_merge( $shortcodes_class_name, $shortcodes );
		
		return $shortcodes_class_name;
	}
	
	add_filter( 'kvell_core_filter_add_vc_shortcode', 'kvell_core_add_highlight_shortcodes' );
}