(function($) {
    'use strict';
    
    var parallaxImageGroup = {};
    edgtf.modules.parallaxImageGroup = parallaxImageGroup;
    
    parallaxImageGroup.edgtfParallaxImageGroup = edgtfParallaxImageGroup;
    
    parallaxImageGroup.edgtfOnWindowLoad = edgtfOnWindowLoad;
    
    $(window).load(edgtfOnWindowLoad);
    
    /*
     All functions to be called on $(window).load() should be in this function
     */
    function edgtfOnWindowLoad() {
        edgtfParallaxImageGroup();
    }
    
    /**
     * Init Parallax Image Group
     */
    function edgtfParallaxImageGroup() {
    	var groups = $('.edgtf-parallax-image-group');

    	if (groups.length) {
    		var setHeight = function(group, images) {
    			var targetHeight = 0;

    			images.each(function(){
    				targetHeight = targetHeight + $(this).height();
    			});

    			group.css('height', targetHeight)
    		}

    		var prepItems = function() {
	    		groups.each(function(){
	    			var group = $(this),
	    				images = group.find('img');

					setHeight(group,images);
	    		});
    		}

    		prepItems();
            ParallaxScroll.init();

    		$(window).resize(function(){
	    		prepItems();
    		});
    	}
   	}
})(jQuery);