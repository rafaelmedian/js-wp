<?php

include_once KVELL_CORE_SHORTCODES_PATH . '/parallax-image-group/functions.php';
include_once KVELL_CORE_SHORTCODES_PATH . '/parallax-image-group/parallax-image-group.php';