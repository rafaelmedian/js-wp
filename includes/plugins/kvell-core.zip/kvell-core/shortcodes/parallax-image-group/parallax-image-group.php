<?php
namespace KvellCore\CPT\Shortcodes\ParallaxImageGroup;

use KvellCore\Lib;

class ParallaxImageGroup implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'edgtf_parallax_image_group';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Parallax Image Group', 'kvell-core' ),
					'base'                      => $this->getBase(),
					'category'                  => esc_html__( 'by KVELL', 'kvell-core' ),
					'icon'                      => 'icon-wpb-parallax-image-group extended-custom-icon',
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
						array(
							'type'			=> 'attach_image',
							'param_name'	=> 'parallax_image_1',
							'heading'		=> esc_html__( 'Parallax Image 1', 'kvell-core' ),
							'description'	=> esc_html__( 'Select image from media library', 'kvell-core' ),
						),
						array(
							'type'			=> 'attach_image',
							'param_name'	=> 'parallax_image_2',
							'heading'		=> esc_html__( 'Parallax Image 2', 'kvell-core' ),
							'description'	=> esc_html__( 'Select image from media library', 'kvell-core' ),
						),
						array(
							'type'			=> 'attach_image',
							'param_name'	=> 'parallax_image_3',
							'heading'		=> esc_html__( 'Parallax Image 3', 'kvell-core' ),
							'description'	=> esc_html__( 'Select image from media library', 'kvell-core' ),
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_shadow',
							'heading'     => esc_html__( 'Enable Shadow', 'kvell-core' ),
							'value'       => array_flip( kvell_edge_get_yes_no_select_array( false, true ) ),
						),
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'parallax_image_1'	=> '',
			'parallax_image_2'	=> '',
			'parallax_image_3'	=> '',
			'enable_shadow' => 'yes'
		);
		
		$params = shortcode_atts( $args, $atts );

		$params['holder_classes'] = $this->getHolderClasses( $params, $args );
		$params['parallax_data_1'] = $this->getParallaxData1( $params, $args );
		$params['parallax_data_2'] = $this->getParallaxData2( $params, $args );
		$params['parallax_data_3'] = $this->getParallaxData3( $params, $args );

		$html = kvell_core_get_shortcode_module_template_part( 'templates/parallax-image-group-template', 'parallax-image-group', '', $params );
		
		return $html;
	}


	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		if ($params['enable_shadow'] == 'yes') {
			$holderClasses[] = 'edgtf-with-shadow';
		}
		
		return implode( ' ', $holderClasses );
	}

	public function getParallaxData1( $params ) {
		$parallaxData = array();

	    $y_absolute = -70;
	    $smoothness = 20; //1 is for linear, non-animated parallax

	    $parallaxData['data-parallax']= '{&quot;y&quot;: '.$y_absolute.', &quot;smoothness&quot;: '.$smoothness.'}';

		return $parallaxData;
	}

	public function getParallaxData2( $params ) {
		$parallaxData = array();

	    $y_absolute = -120;
	    $smoothness = 20; //1 is for linear, non-animated parallax

	    $parallaxData['data-parallax']= '{&quot;y&quot;: '.$y_absolute.', &quot;smoothness&quot;: '.$smoothness.'}';

		return $parallaxData;
	}

	public function getParallaxData3( $params ) {
		$parallaxData = array();

	    $y_absolute = -200;
	    $smoothness = 20; //1 is for linear, non-animated parallax

	    $parallaxData['data-parallax']= '{&quot;y&quot;: '.$y_absolute.', &quot;smoothness&quot;: '.$smoothness.'}';

		return $parallaxData;
	}
}