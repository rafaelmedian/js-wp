<div class="edgtf-parallax-image-group <?php echo esc_attr($holder_classes); ?>">
	<?php for ($i = 1; $i <= 3; $i++) { ?>
		<?php if (!empty (${'parallax_image_'.$i})) { ?>
			<div class="edgtf-parallax-image-group-item" <?php echo kvell_edge_get_inline_attrs(${'parallax_data_'.$i}); ?>>
		        <img src="<?php echo wp_get_attachment_url(${'parallax_image_'.$i}); ?>" alt="<?php echo get_the_title(${'parallax_image_'.$i}); ?>"/>
			</div>
		<?php } ?>
	<?php } ?>
</div>