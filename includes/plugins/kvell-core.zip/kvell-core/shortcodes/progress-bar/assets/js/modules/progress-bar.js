(function($) {
    'use strict';

    var progressBar = {};
    edgtf.modules.progressBar = progressBar;

    progressBar.edgtfInitProgressBars = edgtfInitProgressBars;

    progressBar.edgtfOnDocumentReady = edgtfOnDocumentReady;

    $(document).ready(edgtfOnDocumentReady);

	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
    function edgtfOnDocumentReady() {
        edgtfInitProgressBars();
    }

	/*
	 **	Horizontal progress bars shortcode
	 */
    function edgtfInitProgressBars(){
        var progressBar = $('.edgtf-progress-bar');

        if(progressBar.length){
            progressBar.each(function() {
                var thisBar = $(this),
                    thisBarContent = thisBar.find('.edgtf-pb-content'),
                    percentage = thisBarContent.data('percentage'),
                    percentageNumber = thisBar.find('.edgtf-pb-percent-holder');

                thisBar.appear(function() {
                    edgtfInitToCounterProgressBar(thisBar, percentage);

                    thisBarContent.css('width', '0%');
                    thisBarContent.animate({'width': percentage+'%'}, 2000);
                    percentageNumber.animate({'left': percentage - (percentageNumber.outerWidth() / thisBar.outerWidth() * 100) +'%'}, 2000);

                });
            });
        }
    }

	/*
	 **	Counter for horizontal progress bars percent from zero to defined percent
	 */
    function edgtfInitToCounterProgressBar(progressBar, $percentage){
        var percentage = parseFloat($percentage),
            percent = progressBar.find('.edgtf-pb-percent-holder');

        if(percent.length) {
            percent.each(function() {
                var thisPercent= $(this);
                thisPercent.css('opacity', '1');

                thisPercent.find('.edgtf-pb-percent').countTo({
                    from: 0,
                    to: percentage,
                    speed: 2000,
                    refreshInterval: 50
                });
            });
        }
    }

})(jQuery);