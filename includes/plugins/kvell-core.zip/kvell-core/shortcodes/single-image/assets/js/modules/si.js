(function($) {
    'use strict';

    var singleImage = {};
    edgtf.modules.singleImage = singleImage;

    singleImage.edgtfInitSingleImage = edgtfInitSingleImage;

    singleImage.edgtfOnDocumentReady = edgtfOnDocumentReady;

    $(document).ready(edgtfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function edgtfOnDocumentReady() {
        edgtfInitSingleImage();
    }


    /**
     * Initializes portfolio list follow info gallery hover
     */
    function edgtfInitSingleImage() {
        var cursorTextHolder = $('.edgtf-cursor-info-follow');

        if (cursorTextHolder.length) {

            cursorTextHolder.each(function () {
                var thisCursorTextHolder = $(this),
                    cursorInfoText = thisCursorTextHolder.find('.edgtf-si-cursor-text'),
                    offset = thisCursorTextHolder.offset(); 

                $('body').append(cursorInfoText);

                //info element position
                thisCursorTextHolder.on('mousemove', function (e) {

                    cursorInfoText.css({
                        top: e.clientY,
                        left: e.clientX
                    });
                });

                //show/hide info element
                thisCursorTextHolder.on('mouseenter', function () {

                    thisCursorTextHolder.addClass('edgtf-is-active');
                    cursorInfoText.css('opacity','1');

                }).on('mouseleave', function () {
                    thisCursorTextHolder.removeClass('edgtf-is-active');
                    cursorInfoText.css('opacity','0');
                });

                //check if info element is below or above the targeted portfolio list
                /*$(window).scroll(function(){
                    if (followInfoHolder.hasClass('edgtf-is-active')) {
                        if (followInfoHolder.offset().top < thisPortList.offset().top || followInfoHolder.offset().top > thisPortList.offset().top + thisPortList.outerHeight()) {
                            followInfoHolder.removeClass('edgtf-is-active');
                        }
                    }
                });*/
            });
        }
    }

})(jQuery);