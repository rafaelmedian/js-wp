(function($) {
    'use strict';
    
    var verticalInfoBoxes = {};
    edgtf.modules.verticalInfoBoxes = verticalInfoBoxes;

    verticalInfoBoxes.edgtfInitVerticalInfoBoxes = edgtfInitVerticalInfoBoxes;

    verticalInfoBoxes.edgtfOnDocumentReady = edgtfOnDocumentReady;
    
    $(document).ready(edgtfOnDocumentReady);
    
    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function edgtfOnDocumentReady() {
        edgtfInitVerticalInfoBoxes();
    }

	/*
	 * Init Vertical Info Boxes shortcode
	 */
    function edgtfInitVerticalInfoBoxes() {
        var vibShortcodes = $('.edgtf-vertical-info-boxes-holder');

        if (vibShortcodes.length) {
            vibShortcodes.each(function () {
                var vibInstance = $(this),
                    vibItems = vibInstance.find('.edgtf-vib-item'),
                    vibItemInner = vibInstance.find('.edgtf-vib-item-inner-element'),
                    vibItemContent = vibItemInner.find('> div'),
                    maxHeight;

                var setHeights = function () {
                    maxHeight = 0;

                    vibItemContent.each(function () {
                        if ($(this).height() > maxHeight) {
                            maxHeight = $(this).height();
                        }
                    });

                    vibItemInner.css('height', maxHeight);
                };

                vibInstance.waitForImages(function () {
                    setHeights();
                    vibInstance.css('visibility', 'visible');
                });

                vibItems.each(function(){
                    var thisItem = $(this);

                    thisItem.appear(function() {
                        thisItem.addClass('edgtf-appeared');
                    },{accX: 0, accY: edgtfGlobalVars.vars.edgtfElementAppearAmount});
                });

                $(window).resize(function () {
                    setHeights();
                });

                vibItems.on('mouseenter', function () {
                    var currentItem = $(this);

                    if (vibItems.filter('.edgtf-hovered').length) {
                        vibItems.removeClass('edgtf-hovered');
                        setTimeout(function () {
                            currentItem.addClass('edgtf-hovered');
                        }, 200);
                    } else {
                        currentItem.addClass('edgtf-hovered');
                    }
                });

                vibInstance.on('mouseleave', function () {
                    if (vibItems.filter('.edgtf-hovered').length) {
                        vibItems.removeClass('edgtf-hovered');
                    }
                });
            });
        }
    }

})(jQuery);