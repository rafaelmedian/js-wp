<?php

include_once KVELL_CORE_SHORTCODES_PATH . '/vertical-info-boxes/functions.php';
include_once KVELL_CORE_SHORTCODES_PATH . '/vertical-info-boxes/vertical-info-boxes.php';