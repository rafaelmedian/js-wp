<div class="edgtf-vertical-info-boxes-holder">
    <?php $i = 1; ?>
    <?php foreach ($vertical_info_boxes_item_instances as $item): ?>
        <div class="edgtf-vib-item">
            <?php if (!empty($item['item_link'])) { ?>
                <a class="edgtf-vib-item-link" href="<?php echo esc_url($item['item_link']) ?>"
                   target="<?php echo esc_attr($item['item_link_target']); ?>"></a>
            <?php } ?>
            <div class="edgtf-vib-item-inner-element edgtf-vib-item-image-holder">
                <div class="edgtf-vib-item-image-inner">
                    <img class="edgtf-vib-item-image edgtf-vib-image-bottom"
                     src="<?php echo esc_url(wp_get_attachment_url($item['image_bottom_layer'])); ?>"
                     alt="<?php echo get_the_title($item['image_bottom_layer']) ?>"/>

                    <img class="edgtf-vib-item-image edgtf-vib-image-top"
                         src="<?php echo esc_url(wp_get_attachment_url($item['image_top_layer'])); ?>"
                         alt="<?php echo get_the_title($item['image_top_layer']) ?>"/>
                    <?php
                    $img_bgrnd_color = '';
                    $img_border_color = '';
                    if (isset($item['item_background_color'])) {
                        $img_bgrnd_color .= 'background-color:' . $item['item_background_color'] . ';';
                        $img_border_color .= 'border-top-color:' . $item['item_background_color'] . ';';
                        $img_border_color .= 'border-bottom-color:' . $item['item_background_color'] . ';';
                    } ?>
                    <div class="edgtf-vib-item-image-background" <?php echo kvell_edge_inline_style($img_bgrnd_color); ?>></div>
                    <div class="edgtf-vib-extending-background" <?php echo kvell_edge_inline_style($img_bgrnd_color); ?>>
                    </div>
                    <div class="edgtf-vib-arrow" <?php echo kvell_edge_inline_style($img_border_color); ?>></div>
                </div>
            </div>
            <div class="edgtf-vib-item-inner-element edgtf-vib-item-content-holder">
                <div class="edgtf-vib-item-content-inner">
                    <div class="edgtf-vib-item-content">
                        <h3 class="edgtf-vib-item-title"><?php echo esc_attr($item['item_title']) ?></h3>
                        <p class="edgtf-vib-item-description"><?php echo esc_attr($item['item_description']) ?></p>
                        <?php echo kvell_edge_get_button_html(array(
                            'link'       => $item['item_link'],
                            'text'       => !empty($item['item_link_text']) ? $item['item_link_text'] : '',
                            'size'       => 'medium',
                            'type'       => 'simple',
                            'skin'       => 'dark',
                            'icon_pack'  => 'font_awesome',
                            'fa_icon'    => 'fa-chevron-right',
                            'icon_class' => 'edgtf-btn-icon',
                        )); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php $i++ ?>
    <?php endforeach; ?>
</div>