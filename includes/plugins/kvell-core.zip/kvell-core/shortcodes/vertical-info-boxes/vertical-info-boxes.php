<?php
namespace KvellCore\CPT\Shortcodes\VerticalInfoBoxes;

use KvellCore\Lib;

class VerticalInfoBoxes implements Lib\ShortcodeInterface{
    private $base;
    
    public function __construct() {
        $this->base = 'edgtf_vertical_info_boxes';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    /**
     * Returns base for shortcode
     * @return string
     */
    public function getBase() {
        return $this->base;
    }

    /**
     * Maps shortcode to Visual Composer. Hooked on vc_before_init
     */
    public function vcMap() {
        if(function_exists('vc_map')) {
            vc_map(
                array(
                    'name'                      => esc_html__( 'Vertical Info Boxes', 'kvell-core' ),
                    'base'                      => $this->getBase(),
                    'category'                  => esc_html__( 'by KVELL', 'kvell-core' ),
                    'icon'                      => 'icon-wpb-vertical-info-boxes extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array(   
                        array(
                            'type' => 'param_group',
                            'heading' => esc_html__( 'Vertical Info Boxes Item', 'kvell-core' ),
                            'param_name' => 'vertical_info_boxes_item',
                            'params' => array(
                                array(
                                    'type' => 'attach_image',
                                    'heading' => esc_html__( 'Image Bottom Layer', 'kvell-core' ),
                                    'param_name' => 'image_bottom_layer',
                                ),
                                array(
                                    'type' => 'attach_image',
                                    'heading' => esc_html__( 'Image Top Layer', 'kvell-core' ),
                                    'param_name' => 'image_top_layer',
                                ),
                                array(
                                    'type' => 'colorpicker',
                                    'heading' => esc_html__( 'Item Background Color', 'kvell-core' ),
                                    'param_name' => 'item_background_color',
                                    'description' => esc_html__('Background Color behind the item image.', 'kvell-core'),
                                ),
                                array(
                                    'type' => 'textfield',
                                    'heading' => esc_html__( 'Item Title', 'kvell-core' ),
                                    'param_name' => 'item_title',
                                    'admin_label' => true,
                                ),
                                array(
                                    'type' => 'textfield',
                                    'heading' => esc_html__( 'Item Description', 'kvell-core' ),
                                    'param_name' => 'item_description',
                                ),
                                array(
                                    'type' => 'textfield',
                                    'heading' => esc_html__( 'Item Link', 'kvell-core' ),
                                    'param_name' => 'item_link',
                                ),
                                array(
                                    'type' => 'dropdown',
                                    'heading' => esc_html__( 'Item Link Target', 'kvell-core' ),
                                    'param_name' => 'item_link_target',
                                    'value' => array(
                                        esc_html__('Same Window', 'kvell-core') => '_self',
                                        esc_html__('New Window', 'kvell-core') => '_blank'
                                    )
                                ),
                                array(
                                    'type' => 'textfield',
                                    'heading' => esc_html__( 'Item Link Text', 'kvell-core' ),
                                    'param_name' => 'item_link_text',
                                ),
                            ),
                            'description' => esc_html__('All items will be placed in the same row on non-touch devices.', 'kvell-core'),
                        )
                    )
                )
            );
        }
    }

    /**
     * Renders shortcodes HTML
     *
     * @param $atts array of shortcode params
     * @param $content string shortcode content
     * @return string
     */
    public function render($atts, $content = null) {
        $args = array(
            'vertical_info_boxes_item' => ''
        );

        $params = shortcode_atts($args, $atts);
        $params['vertical_info_boxes_item_instances'] = json_decode(urldecode($params['vertical_info_boxes_item']), true);

        $html = kvell_core_get_shortcode_module_template_part('templates/vertical-info-boxes', 'vertical-info-boxes', '', $params);
        
        return $html;
    }
}